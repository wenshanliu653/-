﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
/// <summary>
/// WenShanLiu 20210327
/// 
/// 火花，是活著的熱情，不是活著的目的
/// 努力過後，每個人都值得被愛
/// 有些人只是想透過批評別人，來掩飾自己沒有達成夢想
/// 
/// </summary>

namespace gwd
{
    public partial class Form1 : Form
    {
        string ls_read = string.Empty;
        List<string> lls_read = new List<string>();
        DataTable ldt_result = new DataTable();
        bool lb_click1 = false;
        bool lb_click2 = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        // 點選 轉換經緯度按鈕
        private void button1_Click(object sender, EventArgs e)
        {
            //如果
            if (!lb_click1 || !lb_click2)
            {
                MessageBox.Show("請選取輸入地址文件與輸出excel的地方");
                return;
            }

            //讀取匯入資料
            try
            {
                FileStream fs_source = new FileStream(textBox1.Text.ToString(), FileMode.Open, FileAccess.Read); //開啟File 找txt檔
                StreamReader sr_source = new StreamReader(fs_source, System.Text.Encoding.UTF8);  //1. 串流讀取txt來源 2.將txt檔 限定 UTF8 編碼


                ls_read = sr_source.ReadLine();  //讀取每一行字，給 ls_read 參數

                while (ls_read != null) // 當ls_read 不為空時
                {
                    lls_read.Add(ls_read); //將ls_read 讀取到的，添加到 lls_read 參數 (82行，去接API)
                   
                    ls_read = sr_source.ReadLine(); //讀取每一行字，給 ls_read 參數, 用視窗show 出每一行地址
                    MessageBox.Show(ls_read);   
                }
                sr_source.Close();  //關閉 串流讀取
                fs_source.Close(); // 關帝 資料夾串流
             

            }
            catch (Exception)
            {
                throw;
            }
        
       
            //產生3欄位 (地址，經度，緯度)
            string ls_address = string.Empty;
            string ls_lat = string.Empty;
            string ls_lng = string.Empty;          
            ldt_result.Columns.Add("address");
            ldt_result.Columns.Add("lat");
            ldt_result.Columns.Add("lng");


            for (int i = 0; i < lls_read.Count; i++) 
            {
                DataRow ldr = ldt_result.NewRow();
                ls_address = lls_read.ElementAt(i);
                ldr["address"] = ls_address;


                //GOOGLE api 串接網址 (JSON類型資料)
                //key 序號 要去google Map API 申請憑證
                var url = String.Format("https://maps.googleapis.com/maps/api/geocode/json?address={0}&key=", ls_address);
            

                //解析API (可參考 google 開放原碼)
                WebResponse response = null;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                response = request.GetResponse();
                if (response != null)
                {
                    string str = null;
                    using (Stream stream = response.GetResponseStream())
                    {
                        using (StreamReader streamReader = new StreamReader(stream))
                        {
                            str = streamReader.ReadToEnd();
                        }
                    }
                    //轉換JSON
                    GeoResponse geoResponse = JsonConvert.DeserializeObject<GeoResponse>(str);
                    if (geoResponse.Status == "OK")
                    {
                        int count = geoResponse.Results.Length;
                        for (int j = 0; j < count; j++)
                        {
                            ls_lat = geoResponse.Results[j].Geometry.Location.Lat.ToString();
                            ls_lng = geoResponse.Results[j].Geometry.Location.Lng.ToString();
                        }
                    }
                }
                ldr["lat"] = ls_lat;
                ldr["lng"] = ls_lng;
                ldt_result.Rows.Add(ldr);
            }

            // DataGridView 顯示串接結果
            dataGridView1.DataSource = ldt_result;


            try
            {    //當串接結果 為空值 或 DataGidView 為空值 ，則顯示Exception 
        
                if (ldt_result == null || ldt_result.Columns.Count == 0)
                {
                    throw new Exception("空的!\n");
                }

                //產生Excel
                Excel.Application excelApp = new Excel.Application();
                //在Excel內添加第一個worksheet
                excelApp.Workbooks.Add();
                Excel._Worksheet workSheet = excelApp.ActiveSheet;

                //填上每一欄 
                for (int i = 0; i < ldt_result.Columns.Count; i++)
                {
                    workSheet.Cells[1, (i + 1)] = ldt_result.Columns[i].ColumnName;
                }
                //填上每一列的值 (經度，緯度)
                for (int i = 0; i < ldt_result.Rows.Count; i++)
                {
                    for (int j = 0; j < ldt_result.Columns.Count; j++)
                    {
                        workSheet.Cells[(i + 2), (j + 1)] = ldt_result.Rows[i][j];
                    }
                }



                // 存Excel檔案
    
                try
                {    
                    workSheet.SaveAs(textBox2.Text + "Address2LntLat.xlsx");
                    excelApp.Quit();
                    //MessageBox.Show("Excel File Saved!");
                }
                catch (Exception ex)
                {
                    throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n" + ex.Message);
                }
            }
            catch (Exception ex)
            {

                throw new Exception("ExportToExcel: \n" + ex.Message);
            }
            
        //  
            
            
            
        }

        //當click到第一個欄位的觸發程序 跳出資料夾選取
        private void textBox1_TextChanged(object sender, EventArgs e){}
        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            lb_click1 = true;
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                textBox1.Text = openFileDialog1.FileName.ToString();
            }
        }


        //當click到第二個欄位的觸發程序 ，顯示產出Excel 的出讀取位置
        private void textBox2_TextChanged(object sender, EventArgs e){}
       

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            lb_click2 = true;
            if (folderBrowserDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK) 
            {
                textBox2.Text = folderBrowserDialog1.SelectedPath.ToString()+"\\";
            }
        }

   
    }
}

//GOOGLE　API 方法 (參考GOOGLE MAP API 官方文件)
    public class GeoLocation
    {
        public decimal Lat { get; set; }
 
        public decimal Lng { get; set; }
    }
 
    public class GeoGeometry
    {
        public GeoLocation Location { get; set; }
    }
 
    public class GeoResult
    {
        public GeoGeometry Geometry { get; set; }
    }
 
    public class GeoResponse
    {
        public string Status { get; set; }
 
        public GeoResult[] Results { get; set; }
    }

public class AddressComponent
    {
        public string long_name { get; set; }
        public string short_name { get; set; }
        public List<string> types { get; set; }
    }

    public class Northeast
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }

    public class Southwest
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }

    public class Bounds
    {
        public Northeast northeast { get; set; }
        public Southwest southwest { get; set; }
    }

    public class Location
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }

    public class Northeast2
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }

    public class Southwest2
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }

    public class Viewport
    {
        public Northeast2 northeast { get; set; }
        public Southwest2 southwest { get; set; }
    }

    public class Geometry
    {
        public Bounds bounds { get; set; }
        public Location location { get; set; }
        public string location_type { get; set; }
        public Viewport viewport { get; set; }
    }

    public class Result
    {
        public List<AddressComponent> address_components { get; set; }
        public string formatted_address { get; set; }
        public Geometry geometry { get; set; }
        public bool partial_match { get; set; }
        public string place_id { get; set; }
        public List<string> types { get; set; }
    }

    public class RootObject
    {
        public List<Result> results { get; set; }
        public string status { get; set; }
    }

