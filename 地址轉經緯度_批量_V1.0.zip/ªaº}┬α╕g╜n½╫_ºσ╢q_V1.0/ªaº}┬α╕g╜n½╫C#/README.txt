
project：給地址轉換經緯度
===========================
STEP 1
在資料夾找到AddressList.txt (UTF-8)
把要轉換地址複製貼上，原檔名存檔

STEP2
開啟C#程式

STEP3
選擇 AddressList.txt 進行轉換資料

STEP4 
選擇要匯出存檔EXCEL 位置

STEP5 
按下Button，等待一陣子資料傳送